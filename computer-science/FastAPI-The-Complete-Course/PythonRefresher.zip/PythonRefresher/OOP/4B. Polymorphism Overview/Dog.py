from Animal import *

class Dog(Animal):

    def talk(self): 
        print('Bark')