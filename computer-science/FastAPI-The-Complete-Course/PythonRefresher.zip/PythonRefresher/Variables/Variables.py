"""
Variables
"""

first_name = "Eric"
print(first_name)
first_name = "Melissa"
print(first_name)














